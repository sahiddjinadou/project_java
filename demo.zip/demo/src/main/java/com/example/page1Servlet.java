package com.example;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name="page1", urlPatterns = "/page1")
public class page1Servlet extends HttpServlet{
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException, IOException
    {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");

        PrintWriter out = resp.getWriter();

        // c'est notre porte de sortie
        out.println("<header style='position: sticky; top: 0; padding: 10px 12px; background-color: #333; color: white;'><nav><ul style='display: flex; justify-content: space-around; align-items: center'><li><a style='color: #eee;' href='/demo/home'>Accueil</a></li><li><a style='color: #eee;' href='/demo/about'>A propos</a></li><li><a style='color: #eee;' href='/demo/contact'>Contactez-nous</a></li></ul></nav></header>");
        out.println("<p>Salut depuis la servlet de la part du serveur autre chose !!! </p>");
        out.println("<h1> je suis la page1 </h1>");
    }
}
